package com.cg.rms.client;

import java.text.ParseException;

import com.cg.rms.ui.LoginUIImpl;

public class Client {

	
		public static void main(String args[]) {
			LoginUIImpl lgi=new LoginUIImpl();
			lgi.showMenu();
		}	

}
